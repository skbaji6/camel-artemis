package com.test.service.hello.world.bean;

public class HelloWorld {

    public String welcomeMessage(final String firstName, final String lastName) {
        System.out.println("The firstName is :" + firstName + " and last name is: " + lastName);
        return "Hello " + firstName + " " + lastName + ", welcome to a new world";
    }
}
