package com.test.service.hello.world.bean;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonAutoDetect
public class User {

    private Integer id;
    private String greetingMessage;

    public User() {
    }

    public User(final Integer id, final String username) {
        this.id = id;
        greetingMessage = username;
    }

    @JsonProperty
    public Integer getId() {
        return id;
    }

    public void setId(final Integer id) {
        this.id = id;
    }

    @JsonProperty
    public String getUsername() {
        return greetingMessage;
    }

    public void setUsername(final String username) {
        greetingMessage = username;
    }
}
