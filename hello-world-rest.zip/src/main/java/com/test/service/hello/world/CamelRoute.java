/*
 * #%L
 * Wildfly Camel :: Example :: Camel REST
 * %%
 * Copyright (C) 2013 - 2014 RedHat
 * %%
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * #L%
 */
package com.test.service.hello.world;

import javax.inject.Inject;
import javax.ws.rs.core.MediaType;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.cdi.ContextName;
import org.apache.camel.component.jackson.JacksonDataFormat;
import org.apache.camel.component.mongodb.MongoDbConstants;
import org.apache.camel.model.rest.RestBindingMode;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.test.service.hello.world.bean.HelloWorld;
import com.test.service.hello.world.bean.User;

@ContextName("com.test.service.hello.world")
public class CamelRoute extends RouteBuilder {

    @Inject
    private HelloWorld helloWorld;

    /*
     * @Override public void configure() throws Exception {
     *
     * final SimpleRegistry reg = new SimpleRegistry(); final String textUri =
     * "mongodb://mdm_read:R_csd1COGTBI17!@mdmpocmdb00-db.sys.ds.wolseley.com:27020";
     * final MongoClientURI uri = new MongoClientURI(textUri); final MongoClient
     * connectionBean = new MongoClient(uri); reg.put("mongoC", connectionBean);
     * final DefaultCamelContext camelContext = new DefaultCamelContext(reg);
     * camelContext.addRoutes(taxonomyBuilder);
     *
     * }
     *
     * private final RouteBuilder taxonomyBuilder = new RouteBuilder() {
     */
    @Override
    public void configure() throws Exception {

        /*
         * getContext().addRoutePolicyFactory(new LoggingRoutePolicyFactory());
         *
         * onException(JsonParseException.class).handled(true)
         * .setProperty(CommonConstants.FEI_RESP_CODE_PROP,
         * constant("request.format.error"))
         * .setHeader(Exchange.HTTP_RESPONSE_CODE,
         * constant(400)).bean("responseBuilder");
         *
         * onException(Throwable.class).handled(true)
         * .setProperty(CommonConstants.FEI_RESP_CODE_PROP,
         * constant("error.processing.request"))
         * .setHeader(Exchange.HTTP_RESPONSE_CODE,
         * constant(500)).bean("responseBuilder");
         *
         * restConfiguration().component("servlet").bindingMode(
         * RestBindingMode. json).jsonDataFormat("json-jackson")
         * .endpointProperty("headerFilterStrategy", "#headerFilter"); ;
         */
        final JacksonDataFormat jd = new JacksonDataFormat(User.class);

        // jd.setUnmarshalType();
        // jd.disableFeature(SerializationFeature.FAIL_ON_EMPTY_BEANS);
        getContext().setTracing(true);
        restConfiguration().component("servlet").bindingMode(RestBindingMode.json).jsonDataFormat("json-jackson")
                .dataFormatProperty("prettyPrint", "true").endpointProperty("servletName", "FergusonHelloWorldServlet");
        ;
        rest("/v2").id("Hello World Rest").description("Hello World Rest Services").produces(MediaType.APPLICATION_JSON)
                .get("/{firstName}?lastName={lastName}").outType(User.class).to("direct:getWelcomeMessage")

                .get("/foo/{message}").outType(User.class).to("direct:getSecondServiceCall")

                .get("/{docType}/yay").to("direct:getDocument");

        from("direct:getDocument").process(new Processor() {

            public void process(final Exchange exchange) throws Exception {
                System.out.println("IN THE ECAT CALL");
                final String docType = (String) exchange.getIn().getHeader("docType");

                System.out.println("Value of id: " + docType);
                // final DBObject doc = new BasicDBObject("objectTypeID",
                // objectTypeId)
                // .append("values.FLD_eCatalog Product Details",
                // Fld_eCtalog_product_details);

                final DBObject doc = new BasicDBObject();
                doc.put("docType", docType);
                // doc.put("values.FLD_eCatalog Product Details",
                // Fld_eCtalog_product_details);

                // Sorting data- can be only done against indexed fields
                // final BasicDBObject masterPrd = new BasicDBObject();
                // masterPrd.put("_id", 1);

                // 1 means only include that field and 0 means only exclude that
                // field, ".add" below can be added n times
                // final DBObject fieldFilter =
                // BasicDBObjectBuilder.start().add("values.MP_S_MASTER_PRODUCT",
                // 1)
                // .add("name", 1).get();

                exchange.getIn().setBody(doc);
                // this line filters the field called name from the result to
                // include or exlude data
                // exchange.getIn().setHeader(MongoDbConstants.FIELDS_FILTER,
                // fieldFilter);
                // exchange.getIn().setHeader(MongoDbConstants.SORT_BY,
                // masterPrd);
                // limt results to 5 , dont use this if you want to paginate -
                // use
                // batch size instead
                exchange.getIn().setHeader(MongoDbConstants.LIMIT, 5);

                // // do something with the payload and/or exchange here
                // System.out.println("payload is: " + payload);
            }

        }).to("mongodb:mongoC?database=pocDb&collection=salesorder&operation=findAll");

        from("direct:getSecondServiceCall").process(new Processor() {

            public void process(final Exchange exchange) throws Exception {
                final String payload = (String) exchange.getIn().getHeader("message");
                // do something with the payload and/or exchange here
                System.out.println("payload in getSecondServiceCall is: " + payload);
                final User user = new User(123, "Response from svc2--> " + payload);

                exchange.getIn().setBody(user);
            }

        });

        from("direct:getWelcomeMessage").process(new Processor() {

            public void process(final Exchange exchange) throws Exception {
                final String payload = (String) exchange.getIn().getHeader("lastName");
                // do something with the payload and/or exchange here
                System.out.println("payload is: " + payload);
            }

        }).bean(helloWorld, "welcomeMessage(${header.firstName},${header.lastName})").process(new Processor() {

            public void process(final Exchange exchange) throws Exception {
                final String payload = (String) exchange.getIn().getBody();
                // do something with the payload and/or exchange here
                System.out.println("Return from bean is: " + payload);
            }

        }).removeHeaders("CamelHttp*").setHeader(Exchange.HTTP_METHOD, constant("GET"))

                // .to("http://a06552:8080/Hello-rest/svc/v2/foo/yay").unmarshal(jd);
                .toD("http://a06552:8080/Hello-rest/svc/v2/foo/${body}").unmarshal(jd);

    }
}
