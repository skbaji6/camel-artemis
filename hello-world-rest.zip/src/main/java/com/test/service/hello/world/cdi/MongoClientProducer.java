package com.test.service.hello.world.cdi;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;
import javax.inject.Named;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

@Named
@ApplicationScoped
public class MongoClientProducer {

    private MongoClient connectionBean = null;

    @Produces
    @MongoDbClient
    @Named("mongoC")
    public MongoClient getMongoClient() {

        // System.setProperty("javax.net.ssl.trustStore",
        // "C:\\InstalledApps\\Java\\jdk1.7.0_79\\bin\\mongoStore.ts");
        // System.setProperty("javax.net.ssl.trustStorePassword", "StorePass");
        // final String textUri =
        //
        // "mongodb://FergusonPilot:S1nks_P1p3s@product-shard-00-00-tkfgm.mongodb.net:27017/EN_All_All?authSource=admin";
        // final MongoClientOptions.Builder optionsBuilder =
        // MongoClientOptions.builder().sslEnabled(true)
        // .sslInvalidHostNameAllowed(true);
        // final MongoClientURI uri = new MongoClientURI(textUri,
        // optionsBuilder);
        //
        // final MongoClient connectionBean = new MongoClient(uri);

        return connectionBean;
    }

    @PostConstruct
    public void init() {
        // final String textUri =
        // "mongodb://mdm_read:R_csd1COGTBI17!@mdmpocmdb00-db.sys.ds.wolseley.com:27020/EN_All_All?authSource=admin";
        final String textUri = "mongodb://a01841:27017";
        final MongoClientURI uri = new MongoClientURI(textUri);
        connectionBean = new MongoClient(uri);
    }
}
